package Assignment3;

import java.util.concurrent.TimeUnit;
import  java.util.Scanner;
public class Times {


    private Integer h1 ,m1,s1;
    private Integer h2,m2,s2;


    private void input() {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the first time (hh:mm:ss): ");
        String time1 = scanner.nextLine();
        String[] time1Parts = time1.split(":");
        h1 = Integer.parseInt(time1Parts[0]);
        m1 = Integer.parseInt(time1Parts[1]);
        s1 = Integer.parseInt(time1Parts[2]);

        System.out.print("Enter the second time (hh:mm:ss): ");
        String time2 = scanner.nextLine();
        String[] time2Parts = time2.split(":");
        h2 = Integer.parseInt(time2Parts[0]);
        m2 = Integer.parseInt(time2Parts[1]);
        s2 = Integer.parseInt(time2Parts[2]);
    }

    private void difference() {


        int s = s1 - s2;
        if (s < 0) {
            s += 60;
            m1--;
        }

        int m =  m1-m2;
        if(m <0 ){
            m+=60;
            h1--;
        }


        int h = h1 - h2;
        if (h < 0) {
            h += 24;
        }

        System.out.println("the  difference is  " + h +":"+ m +":"+ s);
    }




    public static void main(String[] args) {
        Times times = new Times();
        times.input();
        times.difference();
    }




}
