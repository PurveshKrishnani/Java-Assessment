package Assignment4;

public class Manager  extends Employee{

    public ManagerType getType() {
        return type;
    }

    public void setType(ManagerType type) {
        this.type = type;
    }

    public Manager(ManagerType type) {
        this.type = type;
    }

//    public Manager(String name, double salary, Integer employeeId ) {
//        super(name, salary, employeeId);
//    }

    public Manager(String name, double salary, Integer employeeId, ManagerType type) {
        super(name, salary, employeeId);
        this.type = type;
    }

    private ManagerType type;

    @Override
    public void setSalary(double salary) {
        if (type == ManagerType.HR){
            super.setSalary(salary + 10000);
        }
        if(type == ManagerType.SALES){
            super.setSalary(salary + 5000);
        }
    }


    public  static  void main(String args[])
    {
        Manager hrManager = new Manager("purvesh",15000,1001, ManagerType.HR);
        hrManager.setSalary(hrManager.getSalary());
        System.out.print(hrManager.getSalary());

        System.out.println("");

        Manager salesManager = new Manager("chirag",15000,1002,ManagerType.SALES);
        salesManager.setType(ManagerType.SALES);
        salesManager.setSalary(salesManager.getSalary());
        System.out.print(salesManager.getSalary());
    }

}
