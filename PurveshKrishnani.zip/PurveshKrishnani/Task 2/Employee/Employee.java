package Employee;

public class Employee {

    private int Id;
    private  String name;
    private double  salary;
    private int age;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }


    @Override
    public String toString() {
        return "Employee{" +
                "Id=" + Id +
                ", name='" + name + '\'' +
                ", salary=" + salary +
                ", age=" + age +
                '}';
    }


    public Employee(int id, double salary, String name, int age) {
        Id = id;
        this.salary = salary;
        this.name = name;
        this.age = age;
    }

    public Employee() {
        Id = Id;
        this.age = age;
        this.salary = salary;
        this.name = name;
    }
}
