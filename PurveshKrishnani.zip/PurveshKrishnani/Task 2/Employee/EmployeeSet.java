package Employee;

import java.util.Optional;
import java.util.TreeSet;
public class EmployeeSet {
    public TreeSet<Employee> getEmpTreeSet() {
        return empTreeSet;
    }

    private TreeSet<Employee> empTreeSet;



    public EmployeeSet(EmpComparator empComparator) {
        empTreeSet = new TreeSet<>(empComparator);
    }



    public Optional addEmployee(Employee employee) {

       if(empTreeSet.add(employee)){
          return   Optional.of("1");
        }
       else{
             return Optional.of("0");
       }
    }

    public static void main(String args[]) {


        Employee emp = new Employee(100, 10000, "purvesh", 23);
        Employee emp1 = new Employee(101, 9000, "chirag", 22);//same as  6
        Employee emp2 = new Employee(102, 11000, "purvesh", 23);
        Employee emp3 = new Employee(103, 8000, "chirag", 21);
        Employee emp4 = new Employee(104, 8000, "purvesh", 21);
        Employee emp5 = new Employee(105, 8001, "chirag", 21);
        Employee emp6 = new Employee(106, 9000, "chirag", 22);  //same as 2
        Employee emp7 = new Employee(107, 9000, "chirag", 21);
        Employee emp8 = new Employee(108, 7000, "chirag", 24);
        Employee emp9 = new Employee(109, 9000, "chirag", 23);


        EmployeeSet listOfEmp = new EmployeeSet(new EmpComparator());
       System.out.println(listOfEmp.addEmployee(emp));
        System.out.println(listOfEmp.addEmployee(emp1));
        System.out.println(listOfEmp.addEmployee(emp2));
        System.out.println(listOfEmp.addEmployee(emp3));

        System.out.println(listOfEmp.addEmployee(emp4));
        System.out.println(listOfEmp.addEmployee(emp5));
        System.out.println(listOfEmp.addEmployee(emp6));
        System.out.println(listOfEmp.addEmployee(emp7));
        System.out.println(listOfEmp.addEmployee(emp8));
        System.out.println(listOfEmp.addEmployee(emp9));


        System.out.println(listOfEmp.getEmpTreeSet());
    }
}
