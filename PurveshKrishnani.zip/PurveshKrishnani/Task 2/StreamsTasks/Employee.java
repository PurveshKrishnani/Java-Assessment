package StreamsTasks;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Employee {

    int id;
    double salary;
    int joiningYear;
    String department;
    String gender;
    int age;
    String name;

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", salary=" + salary +
                ", joiningYear=" + joiningYear +
                ", department='" + department + '\'' +
                ", gender='" + gender + '\'' +
                ", age=" + age +
                ", name='" + name + '\'' +
                '}';
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getJoiningYear() {
        return joiningYear;
    }

    public void setJoiningYear(int joiningYear) {
        this.joiningYear = joiningYear;
    }

    public Employee(int id, String name, int age, String gender, String department, int joiningYear, double salary) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.department = department;
        this.joiningYear = joiningYear;
        this.salary = salary;
    }

    public Employee() {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.department = department;
        this.joiningYear = joiningYear;
        this.salary = salary;
    }


    ///////////////////////////////   actual  code  start  from here  //////////////////////////////////////

    public  void countGender(ArrayList<Employee> employees) {
        Map<String, Long> genderCounts = employees.stream()
                .collect(Collectors.toMap(
                        Employee::getGender,
                        e -> 1L,
                        Long::sum
                ));
        System.out.println("Gender Counts:");
        genderCounts.forEach((gender, count) -> {
            System.out.println(gender + ": " + count);
        });
    }

    public void printAllDepartments(ArrayList<Employee> employees) {
        employees.stream()
                .map(Employee::getDepartment)
                .distinct()
                .forEach(System.out::println);
    }

    public void printAverageAgeByGender(ArrayList<Employee> employees) {
        Map<String, Double> averageAgeByGender = employees.stream()
                .collect(Collectors.groupingBy(
                        employee -> employee.getGender().equalsIgnoreCase("male") ? "Male" : "Female",
                        Collectors.averagingDouble(Employee::getAge)
                ));
        averageAgeByGender.forEach((key, value) -> {
            System.out.println("gender: " + key + ", average  age : " + value);
        });

    }

    public   void  avgSalaryEachDepartment(ArrayList<Employee> employees){
        Map<String , Double>  avgsalry=  employees.stream()
                .collect(Collectors.groupingBy(Employee::getDepartment,
                        Collectors.averagingDouble(Employee::getSalary)));

        avgsalry.forEach((department, avgsalary) -> {
            System.out.println( department + " " + avgsalary);
        });
    }

    public void noOfEmpInEachDepartment(ArrayList<Employee> employees) {
        Map<String, Long> noEmpInDepartment = employees.stream()
                .collect(Collectors.groupingBy(
                        Employee::getDepartment,
                        Collectors.counting()
                ));
        noEmpInDepartment.forEach((department, noOfEmp) -> {
            System.out.println( department + " no  of emp: " + noOfEmp);
        });

    }

    public void noOfGenderAndCountInSales(ArrayList<Employee> employees) {
        List<Employee> salesAndMarketingEmployees = employees.stream()
                .filter(employee -> employee.getDepartment().equals("Sales And Marketing"))
                .collect(Collectors.toList());

        long maleCount = salesAndMarketingEmployees.stream()
                .filter(employee -> employee.getGender().equals("Male"))
                .count();

        long femaleCount = salesAndMarketingEmployees.stream()
                .filter(employee -> employee.getGender().equals("Female"))
                .count();

        System.out.println("no of male  " + maleCount);
        System.out.println("no  of  female" + femaleCount);
    }

    public void heigestPaidEmployee(ArrayList<Employee> employees) {
        Employee highestPaidEmployee = employees.stream()
                .max(Comparator.comparingDouble(Employee::getSalary))
                .get();
        System.out.println("Higest paid  employee : " + highestPaidEmployee.getName());
    }

    public  void  youngestEmp(ArrayList<Employee>employees){
        Employee  young =  employees.stream()
                .min(Comparator.comparing(Employee::getAge))
                .get();
        System.out.println(young);
    }

    public  void  oldestEmpOfOrganisatrion(ArrayList<Employee>employees){
        Employee  old = employees.stream()
                .min(Comparator.comparing(Employee::getJoiningYear))
                .get();
        System.out.println(old);
    }

    public  void   empJoinedAfter2015(ArrayList<Employee> employees){
        List<String>  empNames =  employees.stream()
                .filter(employee -> employee.getJoiningYear() > 2015)
                .map(Employee::getName)
                .collect(Collectors.toList());

        System.out.println(empNames);

    }

    public void averageSalaryByGender(ArrayList<Employee> employees) {
        Map<String, Double> averageSalaryByGender = employees.stream()
                .collect(Collectors.groupingBy(
                        Employee::getGender,
                        Collectors.averagingDouble(Employee::getSalary)
                ));

        averageSalaryByGender.forEach((gender, avgSal) -> {
            System.out.println( gender + "  " + avgSal);
        });
    }

    public void listOfEmployeeInDepartment(ArrayList<Employee> employees) {
        Map<String, List<String>> namesOfEmpByDepartment = employees.stream()
                .collect(Collectors.groupingBy(
                        Employee::getDepartment,
                        Collectors.mapping(
                                Employee::getName,
                                Collectors.toList()
                        )
                ));

        namesOfEmpByDepartment.forEach((department , Empnames) -> {
            System.out.println( department + "  " + Empnames);
        });
    }

    public void averageTotalSalary(ArrayList<Employee> employees) {
        double totalSalary = employees.stream()
                .mapToDouble(Employee::getSalary)
                .sum();

        double averageSalary = employees.stream()
                .mapToDouble(Employee::getSalary)
                .average()
                .orElse(0.0);

        System.out.println("Total salary: " + totalSalary);
        System.out.println("Average salary: " + averageSalary);
    }

    public void maleEmployeesYoungerThan25(ArrayList<Employee> employees) {
        List<Employee> maleEmployeesYounger25 = employees.stream()
                .filter(employee -> employee.getAge() <= 25)
                .collect(Collectors.toList());
            System.out.println(maleEmployeesYounger25);
    }

    public  void  oldestEmpOfOrganisatrionageAndname(ArrayList<Employee>employees){
        Employee  old = employees.stream()
                .min(Comparator.comparing(Employee::getJoiningYear))
                .get();
        System.out.println(old.getDepartment()  + " "+ old.getAge() );
    }



    public static void main(String args[]) {

        Employee emp = new Employee();
        ArrayList<Employee> employees = new ArrayList<>();

        employees.add(new Employee(111, "Vishnu Priya", 32, "Female", "HR", 2011, 25000.0));
        employees.add(new Employee(122, "Vinay Raj", 25, "Male", "Sales And Marketing", 2015, 13500.0));
        employees.add(new Employee(133, "Avinash Reddy", 29, "Male", "Infrastructure", 2012, 18000.0));
        employees.add(new Employee(144, "Bhanu Prasad", 28, "Male", "Product Development", 2014, 32500.0));
        employees.add(new Employee(155, "Aish Roy", 27, "Female", "HR", 2013, 22700.0));
        employees.add(new Employee(166, "Raj Vignesh", 43, "Male", "Security And Transport", 2016, 10500.0));
        employees.add(new Employee(177, "Manu Sharma", 35, "Male", "Account And Finance", 2010, 27000.0));
        employees.add(new Employee(188, "Chandra Mouli", 31, "Male", "Product Development", 2015, 34500.0));
        employees.add(new Employee(199, "Shilpa Shetty", 24, "Female", "Sales And Marketing", 2016, 11500.0));
        employees.add(new Employee(200, "Kumar Raja", 38, "Male", "Security And Transport", 2015, 11000.5));
        employees.add(new Employee(211, "Ameen Kaur", 27, "Female", "Infrastructure", 2014, 15700.0));
        employees.add(new Employee(222, "Sunil Joshi", 25, "Male", "Product Development", 2016, 28200.0));
        employees.add(new Employee(233, "Jyothi Reddy", 27, "Female", "Account And Finance", 2013, 21300.0));
        employees.add(new Employee(244, "Shankar Dada", 24, "Male", "Sales And Marketing", 2017, 10700.5));
        employees.add(new Employee(255, "Alia Butt", 23, "Male", "Infrastructure", 2018, 12700.0));
        employees.add(new Employee(266, "Santhi Pandey", 26, "Female", "Product Development", 2015, 28900.0));
        employees.add(new Employee(277, "Sunil Shetty", 31, "Male", "Product Development", 2012, 35700.0));



//        emp.countGender(employees);
//        emp.printAllDepartments(employees);
//        emp.printAverageAgeByGender(employees);
//        emp.heigestPaidEmployee(employees);
//        emp.empJoinedAfter2015(employees);
//        emp.noOfEmpInEachDepartment(employees);
//        emp.avgSalaryEachDepartment(employees);
//        emp.youngestEmp(employees);
//        emp.oldestEmpOfOrganisatrion(employees);
//        emp.noOfGenderAndCountInSales(employees);
//        emp.averageSalaryByGender(employees);
//        emp.listOfEmployeeInDepartment(employees);
//        emp.averageTotalSalary(employees);
//        emp.maleEmployeesYoungerThan25(employees);

        emp.oldestEmpOfOrganisatrionageAndname(employees);

    }


}
