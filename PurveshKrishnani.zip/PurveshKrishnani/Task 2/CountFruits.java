import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CountFruits {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter input file path:");
        String inputPath = scanner.nextLine();

        Map<String, Integer> fruitCount = getFruitCount(inputPath);

        System.out.println("Fruit Counts:");
        for (Map.Entry<String, Integer> entry : fruitCount.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }

    private static Map<String, Integer> getFruitCount(String inputFilePath) {
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(inputFilePath))) {
            return bufferedReader.lines()
                    .flatMap(line -> Stream.of(line.split(" ")))
                    .map(String::toLowerCase)
                    .collect(Collectors.toMap(
                            Function.identity(),
                            word -> 1,
                            Integer::sum,
                            HashMap::new
                    ));
        } catch (IOException e) {
            e.printStackTrace();
            return new HashMap<>();
        }
    }
}


