import java.time.LocalDate;
import java.util.*;

class Employee {

    int id;
    double salary;
    int joiningYear;
    String department;
    String gender;
    int age;
    String name;

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getJoiningYear() {
        return joiningYear;
    }

    public void setJoiningYear(int joiningYear) {
        this.joiningYear = joiningYear;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public Employee(int id, String name, int age, String gender, String department, int joiningYear, double salary) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.department = department;
        this.joiningYear = joiningYear;
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", salary=" + salary +
                ", joiningYear=" + joiningYear +
                ", department='" + department + '\'' +
                ", gender='" + gender + '\'' +
                ", age=" + age +
                ", name='" + name + '\'' +
                '}';
    }

    public Employee() {
        this.id = id;
        this.salary = salary;
        this.joiningYear = joiningYear;
        this.department = department;
        this.gender = gender;
        this.age = age;
        this.name = name;
    }
    
    public ArrayList<Employee> getEmployees(ArrayList<Employee>  employees) {
        return employees;
    }
    
    public void CountOfGender(ArrayList<Employee>  employees) {
        System.out.println("No of male and female in an organisation");
        int male = 0;
        int female = 0;
        for (Employee e : employees) {
            if (e.getGender().equals("Female")) {
                female++;
            } else {
                male++;
            }
        }
        System.out.println("No of male = " + male + ", No of female = " + female);
    }

    private void listOfdepartment(ArrayList<Employee>  employees) {
        HashSet<String> departmentList = new HashSet();
        System.out.println("List  of  department ");
        for(Employee e :employees)
        {
            departmentList.add(e.getDepartment());
        }

        for (String department : departmentList) {
            System.out.println(department);
        }
    }

    private void avgAgeMaleAndFemale(ArrayList<Employee>  employees) {
        float maleAge = 0;
        float femaleAge = 0;
        int maleCount = 0;
        int femaleCount = 0;
        for (Employee emp : employees) {
            if (emp.getGender().equals("Female")) {
                femaleAge += emp.getAge();
                femaleCount++;
            } else {
                maleAge += emp.getAge();
                maleCount++;
            }
        }
        float avgMen = maleAge / maleCount;
        float avgFemale = femaleAge / femaleCount;
        System.out.println("Avg men age is " + avgMen + " Avg Female age " + avgFemale);
    }

    public void highestPaidEmployee(ArrayList<Employee>  employees) {
        double maxPaid = Integer.MIN_VALUE;
        Employee highestPaidEmployee = null;
        for (Employee emp : employees) {
            if (emp.getSalary() > maxPaid) {
                maxPaid = emp.getSalary();
                highestPaidEmployee = emp;
            }
        }
        if (highestPaidEmployee != null) {
            System.out.println("higest paid employee: " + highestPaidEmployee.getName() + "   and  salary is  " + maxPaid);
        } else {
            System.out.println("no employees found.");
        }
    }

    public  void  employeesJoinedAfter2015(ArrayList<Employee>  employees){
        List<String> emplist = new ArrayList<>();
        for (Employee emp :employees){
            if (emp.getJoiningYear() > 2015){
                emplist.add(emp.getName());
            }
        }
        System.out.println(emplist);
    }

    public void employeesInEachDepartment(ArrayList<Employee>  employees) {
        Map<String, Integer> noOfEmpInDepartment = new HashMap<>();
        for (Employee emp : employees) {
            String department = emp.getDepartment();
            if (noOfEmpInDepartment.containsKey(department)) {
                noOfEmpInDepartment.put(department, noOfEmpInDepartment.get(department) + 1);
            } else {
                noOfEmpInDepartment.put(department, 1);
            }
        }
        System.out.println("number  of emp in each department:");
        for (Map.Entry<String, Integer> entry : noOfEmpInDepartment.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }

    public  void    youngestMaleEmployee(ArrayList<Employee> employees){
        double young = Integer.MAX_VALUE;
        Employee youngemp = null;

        for(Employee  emp : employees){
            if(emp.getAge() < young  &&  emp.getDepartment().equals("Product Development") ){
                youngemp=emp;
            }
        }

        System.out.println(youngemp);

    }

    public void mostWorkingExperience(ArrayList<Employee> employees) {
        int mostexp = Integer.MIN_VALUE;
        String name = "";
        for (Employee emp : employees) {
            int exp = LocalDate.now().getYear() - emp.getJoiningYear();
            if (exp > mostexp) {
                mostexp = exp;
                name = emp.getName();
            }
        }
        System.out.println("most experience person is " + name);
    }

    public void averageSalaryOfEachDepartment(ArrayList<Employee> employees) {
        Map<String, Double> departmentSalaries = new HashMap<>();
        Map<String, Integer> departmentCounts = new HashMap<>();

        for (Employee emp : employees) {
            String department = emp.getDepartment();
            double salary = emp.getSalary();

            departmentSalaries.merge(department, salary, Double::sum);
            departmentCounts.merge(department, 1, Integer::sum);
        }

        System.out.println("Average salary of each department:");
        for (Map.Entry<String, Double> entry : departmentSalaries.entrySet()) {
            String department = entry.getKey();
            double totalSalary = entry.getValue();
            int employeeCount = departmentCounts.get(department);
            double averageSalary = totalSalary / employeeCount;

            System.out.println(department + ": " + averageSalary);
        }
    }

    public void MaleAndFemaleInsales(ArrayList<Employee> employees) {

        int maleCount = 0;
        int femaleCount = 0;

        for (Employee employee : employees) {
            if (employee.getGender().equalsIgnoreCase("Male")  &&  employee.getDepartment().equals("Sales And Marketing")) {
                maleCount++;
            } else if (employee.getGender().equalsIgnoreCase("Female")   &&  employee.getDepartment().equals("Sales And Marketing")) {
                femaleCount++;
            }
        }
        System.out.println("Male  in sales and marketing = "+maleCount  +    "female  in sales  and marketing  ="+femaleCount );
    }

    public void AvgSalaryOfMaleAndFemale(ArrayList<Employee> employees) {
        int maleCount = 0;
        int femaleCount = 0;
        double maleSalary = 0;
        double femaleSalary = 0;

        for (Employee emp : employees) {
            String gender = emp.getGender();
            double salary = emp.getSalary();

            if (gender != null && gender.equalsIgnoreCase("male")) {
                maleCount++;
                maleSalary += salary;
            } else if (gender != null && gender.equalsIgnoreCase("female")) {
                femaleCount++;
                femaleSalary += salary;
            }
        }

        double maleAvgSalary = maleCount > 0 ? maleSalary / maleCount : 0;
        double femaleAvgSalary = femaleCount > 0 ? femaleSalary / femaleCount : 0;

        System.out.println("Male avg salary: " + maleAvgSalary);
        System.out.println("Female avg salary: " + femaleAvgSalary);
    }

    public void empbyDepartments(ArrayList<Employee> employees) {
        Map<String, ArrayList<String>> listofEmpByDepartments = new HashMap<>();
        for (Employee emp : employees) {
            String department = emp.getDepartment(); // assuming Employee class has a getDepartment() method
            if (!listofEmpByDepartments.containsKey(department)) {
                listofEmpByDepartments.put(department, new ArrayList<>());
            }
            listofEmpByDepartments.get(department).add(emp.getName()); // assuming Employee class has a getName() method
        }

        Iterator<Map.Entry<String, ArrayList<String>>> iterator = listofEmpByDepartments.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, ArrayList<String>> entry = iterator.next();
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }
    }

    public   void   AvgsalaryAndTotalSalary(ArrayList<Employee> employees){
        double totalsalary = 0;
        int count=0;
        for(Employee emp:employees){
            totalsalary += emp.getSalary();
            count++;
        }

        double  avg  =  totalsalary/count;
        System.out.println("Total  salary  of  all  is  "+ totalsalary+"   and  avg salary  is "+ avg);
    }

    public   void  youngerEmp25(ArrayList<Employee> employees){
        ArrayList<Employee>  young = new ArrayList<>();
        for (Employee emp :employees){
            if(emp.getAge() <=  25){
                young.add(emp);
            }
        }
        System.out.println("Employye  younger  thn 25  are  ");
        System.out.println(young);

    }

    public void oldestEmployee(ArrayList<Employee> employees) {
        int oldestAge = Integer.MIN_VALUE;
        Employee oldemp = null;
        int currYear = LocalDate.now().getYear();

        for (Employee emp : employees) {
            int joiningYear = emp.getJoiningYear();
            int age = currYear - joiningYear;
            if (age > oldestAge) {
                oldestAge = age;
                oldemp = emp;
            }
        }

        System.out.println("Oldest employee is " + oldemp.getName() + ", age is " + oldemp.getAge() + ", department is " + oldemp.getDepartment());
    }

    public  static  void main(String args[]){

        Employee  emp = new Employee();
        ArrayList<Employee> employees = new ArrayList<>();

        employees.add(new Employee(111, "Vishnu Priya", 32, "Female", "HR", 2011, 25000.0));
        employees.add(new Employee(122, "Vinay Raj", 25, "Male", "Sales And Marketing", 2015, 13500.0));
        employees.add(new Employee(133, "Avinash Reddy", 29, "Male", "Infrastructure", 2012, 18000.0));
        employees.add(new Employee(144, "Bhanu Prasad", 28, "Male", "Product Development", 2014, 32500.0));
        employees.add(new Employee(155, "Aish Roy", 27, "Female", "HR", 2013, 22700.0));
        employees.add(new Employee(166, "Raj Vignesh", 43, "Male", "Security And Transport", 2016, 10500.0));
        employees.add(new Employee(177, "Manu Sharma", 35, "Male", "Account And Finance", 2010, 27000.0));
        employees.add(new Employee(188, "Chandra Mouli", 31, "Male", "Product Development", 2015, 34500.0));
        employees.add(new Employee(199, "Shilpa Shetty", 24, "Female", "Sales And Marketing", 2016, 11500.0));employees.add(new Employee(200, "Kumar Raja", 38, "Male", "Security And Transport", 2015, 11000.5));
        employees.add(new Employee(211, "Ameen Kaur", 27, "Female", "Infrastructure", 2014, 15700.0));
        employees.add(new Employee(222, "Sunil Joshi", 25, "Male", "Product Development", 2016, 28200.0));
        employees.add(new Employee(233, "Jyothi Reddy", 27, "Female", "Account And Finance", 2013, 21300.0));
        employees.add(new Employee(244, "Shankar Dada", 24, "Male", "Sales And Marketing", 2017, 10700.5));
        employees.add(new Employee(255, "Alia Butt", 23, "Male", "Infrastructure", 2018, 12700.0));
        employees.add(new Employee(266, "Santhi Pandey", 26, "Female", "Product Development", 2015, 28900.0));
        employees.add(new Employee(277, "Sunil Shetty", 31, "Male", "Product Development", 2012, 35700.0));


            emp.CountOfGender(employees);
            emp.listOfdepartment(employees);
            emp.avgAgeMaleAndFemale(employees);
            emp.highestPaidEmployee(employees);
            emp.employeesJoinedAfter2015(employees);
            emp.employeesInEachDepartment(employees);
            emp.youngestMaleEmployee(employees);
            emp.mostWorkingExperience(employees);
            emp.averageSalaryOfEachDepartment(employees);
            emp.MaleAndFemaleInsales(employees);
            emp.AvgSalaryOfMaleAndFemale(employees);
            emp.empbyDepartments(employees);
            emp.AvgsalaryAndTotalSalary(employees);
            emp.youngerEmp25(employees);
            emp.oldestEmployee(employees);
    }
}
