public class Main {

    public  static  void main(String args[]){

        Clerk clerk = new Clerk("purvesh" ,15000,1001,50,50);

        System.out.println( clerk.getSalary());
        clerk.setSpeed(90);
        clerk.setAccuracy(90);
        clerk.setSalary(clerk.getSalary());

        System.out.println( clerk.getSalary());


        clerk.setSpeed(80);
        clerk.setAccuracy(80);
        clerk.setSalary(clerk.getSalary());

        System.out.println( clerk.getSalary());


        Manager hrManager = new Manager("purvesh",15000,1001, Employee.ManagerType.HR);
        hrManager.setSalary(hrManager.getSalary());
        System.out.print(hrManager.getSalary());

        System.out.println("");

        Manager salesManager = new Manager("chirag",15000,1002, Employee.ManagerType.SALES);
        salesManager.setType(Employee.ManagerType.SALES);
        salesManager.setSalary(salesManager.getSalary());
        System.out.print(salesManager.getSalary());


    }


}


