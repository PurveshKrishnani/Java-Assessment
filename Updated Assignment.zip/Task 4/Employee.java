public  class Employee {

    private  Integer employeeId;
    private  double  salary;
    private String name;

    enum  ManagerType{
        HR,
        SALES
    }

    public Employee() {
        this.name = "";
        this.employeeId = 0;
        this.salary = 0.0;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }


    public Employee(String name, double salary, Integer employeeId) {
        this.name = name;
        this.salary = salary;
        this.employeeId = employeeId;
    }

}
