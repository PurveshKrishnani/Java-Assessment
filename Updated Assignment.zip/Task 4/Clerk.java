
public class Clerk   extends Employee{

    public   int speed;
    public  int  accuracy;

    public Clerk(int speed, int accuracy) {
        this.speed = speed;
        this.accuracy = accuracy;
    }

    public Clerk(String name, double salary, Integer employeeId, int speed, int accuracy) {
        super(name, salary, employeeId);
        this.speed = speed;
        this.accuracy = accuracy;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
        this.setSalary(this.getSalary());
    }

    public void setAccuracy(int accuracy) {
        this.accuracy = accuracy;
        this.setSalary(this.getSalary());
    }
    public int getAccuracy() {
        return accuracy;
    }

    public Clerk() {
        this.speed = 0;
        this.accuracy = 0;
    }

    @Override
    public void setSalary(double salary) {
        if (speed >= 70 && accuracy >= 80) {
            super.setSalary(salary + 1000);
        } else {
            super.setSalary(salary);
        }
    }
}


