
public class Manager  extends Employee{
    private ManagerType type;


    public ManagerType getType() {
        return type;
    }

    public void setType(ManagerType type) {
        this.type = type;
    }

    public Manager(ManagerType type) {
        this.type = type;
    }


    public Manager(String name, double salary, Integer employeeId, ManagerType type) {
        super(name, salary, employeeId);
        this.type = type;
    }


    @Override
    public void setSalary(double salary) {
        if (type == ManagerType.HR){
            super.setSalary(salary + 10000);
        }
        if(type == ManagerType.SALES){
            super.setSalary(salary + 5000);
        }
    }


}
