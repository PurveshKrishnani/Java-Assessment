public class Main {

    public static void main(String args[]){

        Espncricinfo espncricinfo = new Espncricinfo();
        Batsman batsman = new Batsman();

        espncricinfo.addBatsman(new Batsman("Purvesh", 10000, 20, 30));
        espncricinfo.addBatsman(new Batsman("ramesh", 20000, 20, 20));

        Batsman batsman3 = new Batsman("vinay", 30000, 20, 30);
        Batsman batsman4 = new Batsman("rajesh", 40000, 30, 90);
        Batsman batsman5 = new Batsman("varun", 30000, 50, 30);
        Batsman batsman6 = new Batsman("raju", 40000, 80, 40);

        espncricinfo.addBatsman(batsman3);
        espncricinfo.addBatsman(batsman4);
        espncricinfo.addBatsman(batsman5);
        espncricinfo.addBatsman(batsman6);

        espncricinfo.getBatsmans();
        espncricinfo.getBatsman(100004);
        System.out.println(espncricinfo.getNoOfBatsmen());
    }

}
