
import java.util.Arrays;
import java.util.Optional;

public class Espncricinfo {

    public  static final int SIZE = 50;
    public Batsman[] batsmans;
    public  int noOfBatsmen;

    @Override
    public String toString() {
        return "Espncricinfo{" +
                "batsmans=" + Arrays.toString(batsmans) +
                ", noOfBatsmen=" + noOfBatsmen +
                '}';
    }

    public void setBatsmans(Batsman[] batsmans) {
        this.batsmans = batsmans;
    }

    public void setNoOfBatsmen(int noOfBatsmen) {
        this.noOfBatsmen = noOfBatsmen;
    }

    public  Espncricinfo() {
        batsmans = new Batsman[SIZE];
        noOfBatsmen = 0;
    }

    public void getBatsmans() {
        for (Batsman batsman : batsmans) {
            if (batsman != null) {
                System.out.println(batsman);
            }
        }
    }

    public int getNoOfBatsmen() {
        int count =0;
        for (Batsman batsman : batsmans) {
            if (batsman != null) {
                count++;
            }
        }
        return count;
    }

    public int addBatsman(Batsman batsman) {
        if (noOfBatsmen < SIZE) {
            batsmans[noOfBatsmen] = batsman;
            noOfBatsmen++;
            return batsman.getId();
        }
        return -1;
    }

    public Batsman updateBatsmanStats(int id, int centuries, int halfCenturies) {
        for (Batsman batsman : batsmans) {
            if (batsman != null && batsman.getId() == id) {
                batsman.setCenturies(centuries);
                batsman.setHalfCenturies(halfCenturies);
                return batsman;
            }
        }
        return null;
    }

    public Optional<Batsman> getBatsman(int batsmanId) {
        for (Batsman batsman : batsmans) {
            if (batsman != null && batsman.getId() == batsmanId) {
                System.out.println( Optional.of(batsman));
            }
        }
        return Optional.empty();

    }
}
