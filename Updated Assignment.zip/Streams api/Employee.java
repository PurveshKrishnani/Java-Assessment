
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Employee {


    int id;
    double salary;
    int joiningYear;
    String department;
    String gender;
    int age;
    String name;

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getJoiningYear() {
        return joiningYear;
    }

    public void setJoiningYear(int joiningYear) {
        this.joiningYear = joiningYear;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public Employee(int id, String name, int age, String gender, String department, int joiningYear, double salary) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.department = department;
        this.joiningYear = joiningYear;
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", salary=" + salary +
                ", joiningYear=" + joiningYear +
                ", department='" + department + '\'' +
                ", gender='" + gender + '\'' +
                ", age=" + age +
                ", name='" + name + '\'' +
                '}';
    }

    public Employee() {
        this.id = id;
        this.salary = salary;
        this.joiningYear = joiningYear;
        this.department = department;
        this.gender = gender;
        this.age = age;
        this.name = name;
    }


    public void CountOfMaleAndFemale(ArrayList<Employee> employees) {
        Map<String, Long> numberOfMaleAndFemales = employees.stream()
                .collect(Collectors.groupingBy(
                        Employee::getGender,
                        Collectors.counting()
                ));
        numberOfMaleAndFemales.forEach((k, v) -> System.out.println(k + ": " + v));
    }

    public  void  allDepartments(ArrayList<Employee> employees) {

        employees.stream().map(Employee::getDepartment).distinct().forEach(System.out::println);
    }

    public void avgAgeOfGender(ArrayList<Employee> employees) {
        Map<String, Double> averageage = employees.stream()
                .collect(Collectors.groupingBy(Employee::getGender,  Collectors.averagingDouble(Employee::getAge)));

        averageage.forEach((k, v) -> System.out.println(k + ": " + v));
    }

    public  void highestPaidEmployee(ArrayList<Employee>  employees) {
        System.out.println(employees.stream().map(Employee::getSalary)
                .collect(Collectors.maxBy(Comparator.comparingDouble(Double::doubleValue))));
    }
    public void  joinedAfter2015(ArrayList<Employee>  employees) {
        employees.stream().filter(Emp -> Emp.getJoiningYear() > 2015).forEach(System.out::println);

    }


    public  void noOfEmpInEachDepartment(ArrayList<Employee>  employees) {

        Map<String, Long>  noOfEmp = employees.stream()
                .collect(Collectors.groupingBy(Employee::getDepartment , Collectors.counting()));
        noOfEmp.forEach((k, v) -> System.out.println(k + ": " + v));

    }


    public  void  oldEmployee(ArrayList<Employee>  employees) {
        Optional<Employee> oldEmp = employees.stream().collect(Collectors.minBy(Comparator.comparingInt(Employee::getJoiningYear)));
        System.out.println(oldEmp);
    }


    public  void   averageSalaryOfEachDepartment(ArrayList<Employee>  employees) {
        Map<String, Double>  avgsalaray =  employees.stream()
                .collect(Collectors.groupingBy(Employee::getDepartment, Collectors.averagingDouble(Employee::getSalary)));
        avgsalaray.forEach((k, v) -> System.out.println(k + ": " + v));

    }


    public void youngestMale (ArrayList<Employee>  employees) {
        Optional<Employee>  youngMale = employees.stream().filter(emp -> emp.getGender()
                        .equals("Male"))
                .collect(Collectors.minBy(Comparator.comparingInt(Employee::getAge)));
        System.out.println(youngMale);
    }

    public  void  maleAndFemalInSales(ArrayList<Employee>  employees) {
        Map<String, Long>  salesempmaleAndFemale =   employees.stream().filter(emp -> emp.getDepartment().equals("Sales And Marketing"))
                .collect(Collectors.groupingBy(Employee::getGender, Collectors.counting()));
        salesempmaleAndFemale.forEach((k, v) -> System.out.println(k + ": " + v));

    }

    public  void avgsalaryOfMaleAndfemale(ArrayList<Employee>  employees) {
        Map<String , Double>  avgsalary =  employees.stream()
                .collect(Collectors.groupingBy(Employee::getGender, Collectors.averagingDouble(Employee::getSalary)));
        avgsalary.forEach((k, v) -> System.out.println(k + ": " + v));

    }

    public  void youngerThan25(ArrayList<Employee>  employees) {
        Stream<Employee> young25 = employees.stream().filter(emp -> emp.age < 25);
        young25.forEach(System.out::println);
    }


    public  void  oldEmployeenameAnddepart(ArrayList<Employee>  employees) {
        Optional<Employee> oldestEmployee = employees.stream().collect(Collectors.minBy(Comparator.comparingInt(Employee::getJoiningYear)));
        if (oldestEmployee.isPresent()) {
            System.out.println("old  emp anme" + oldestEmployee.get().getName() + "  his  department " + oldestEmployee.get().getDepartment() );
        } else {
            System.out.println("The employee list is empty.");
        }
    }

    public static void main(String[] args) {


        Employee  emp = new Employee();
        ArrayList<Employee> employees = new ArrayList<>();

        employees.add(new Employee(111, "Vishnu Priya", 32, "Female", "HR", 2011, 25000.0));
        employees.add(new Employee(122, "Vinay Raj", 25, "Male", "Sales And Marketing", 2015, 13500.0));
        employees.add(new Employee(133, "Avinash Reddy", 29, "Male", "Infrastructure", 2012, 18000.0));
        employees.add(new Employee(144, "Bhanu Prasad", 28, "Male", "Product Development", 2014, 32500.0));
        employees.add(new Employee(155, "Aish Roy", 27, "Female", "HR", 2013, 22700.0));
        employees.add(new Employee(166, "Raj Vignesh", 43, "Male", "Security And Transport", 2016, 10500.0));
        employees.add(new Employee(177, "Manu Sharma", 35, "Male", "Account And Finance", 2010, 27000.0));
        employees.add(new Employee(188, "Chandra Mouli", 31, "Male", "Product Development", 2015, 34500.0));
        employees.add(new Employee(199, "Shilpa Shetty", 24, "Female", "Sales And Marketing", 2016, 11500.0));
        employees.add(new Employee(200, "Kumar Raja", 38, "Male", "Security And Transport", 2015, 11000.5));
        employees.add(new Employee(211, "Ameen Kaur", 27, "Female", "Infrastructure", 2014, 15700.0));
        employees.add(new Employee(222, "Sunil Joshi", 25, "Male", "Product Development", 2016, 28200.0));
        employees.add(new Employee(233, "Jyothi Reddy", 27, "Female", "Account And Finance", 2013, 21300.0));
        employees.add(new Employee(244, "Shankar Dada", 24, "Male", "Sales And Marketing", 2017, 10700.5));
        employees.add(new Employee(255, "Alia Butt", 23, "Male", "Infrastructure", 2018, 12700.0));
        employees.add(new Employee(266, "Santhi Pandey", 26, "Female", "Product Development", 2015, 28900.0));
        employees.add(new Employee(277, "Sunil Shetty", 31, "Male", "Product Development", 2012, 35700.0));



//	        emp.CountOfMaleAndFemale(employees);
//	        emp.allDepartments(employees);
//	        emp.avgAgeOfGender(employees);
//	        emp.highestPaidEmployee(employees);
//	        emp.joinedAfter2015(employees);
//	        emp.noOfEmpInEachDepartment(employees);
//	        emp.averageSalaryOfEachDepartment(employees);
//	        emp.youngestMale(employees);
//	        emp.oldEmployee(employees);
//	        emp.maleAndFemalInSales(employees);
//	        emp.avgsalaryOfMaleAndfemale(employees);
//	        emp.youngerThan25(employees);
        emp.oldEmployeenameAnddepart(employees);


    }



}
