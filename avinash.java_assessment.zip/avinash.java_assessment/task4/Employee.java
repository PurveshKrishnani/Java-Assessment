package task4;

public class Employee {
    private String name;
    private int employeeId;
    private double salary;

    enum ManagerType{
        HR,
        Sales
    }

    public Employee(String name, int employeeId, double salary) {
        this.name = name;
        this.employeeId = employeeId;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public static void main(String[] args) {
        // manager salary increment
        Manager hr = new Manager("avinash",1,52000);
        hr.setType(ManagerType.HR);
        hr.setSalary(52000);
        System.out.println("Hr salaray : "+ hr.getSalary());
        // sales salary increment
        Manager sales = new Manager("bhanu",2,30000);
        sales.setType(ManagerType.Sales);
        sales.setSalary(30000);
        System.out.println("Sales Manager Salary : "+sales.getSalary());
        // clerk adding
        Clerk p1 = new Clerk("ram",12,8000,80,104);
        p1.setSalary(8000);
        System.out.println("Clerk "+p1.getName()+" has salary of "+ p1.getSalary());
        Clerk p2 = new Clerk("ela",20,6000,60,90);
        p2.setSalary(6000);
        System.out.println("Clerk "+p2.getName()+" has salary of "+ p2.getSalary());
    }
}
class Manager extends Employee {
    private ManagerType type;

    public ManagerType getType() {
        return type;
    }

    public void setType(ManagerType type) {
        this.type = type;
    }
    public Manager(String name, int employeeId, double salary) {
        super(name, employeeId, salary);
    }
    public void setSalary(double salary){
        if(type == ManagerType.HR){
            super.setSalary(salary+10000);
        } else if (type == ManagerType.Sales) {
            super.setSalary(salary+5000);
        }
    }
}
class Clerk extends Employee{
    int speed;
    int accuracy;
    private boolean extraSalary;

    public Clerk(String name, int employeeId, double salary, int speed, int accuracy) {
        super(name, employeeId, salary);
        this.speed = speed;
        this.accuracy = accuracy;
        this.extraSalary = false;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    private void setSalary() {
    }

    public int getAccuracy() {
        return accuracy;
    }

    public void setAccuracy(int accuracy) {
        this.accuracy = accuracy;
    }

    public void setSalary(double salary){
        if(speed > 70 && accuracy > 79 && !extraSalary){
            super.setSalary(salary+1000);
            extraSalary = true;
        }
    }
}
