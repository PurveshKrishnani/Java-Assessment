package task1;

public class Espncricinfo {
    private int size = 50;
    public batsman[] batsmans;
    private int noOfBatsmen;

    public Espncricinfo() {
        this.batsmans = new batsman[size];
    }

    // q.2
    public batsman[] getBatsmans(){
        return batsmans;
    }

    // returns number of batsmen q.3
    public int  getNoOfBatsmen(){
        return noOfBatsmen;
    }

    // add batsman q.4
    public int  addBatsman(String name, int runsScored, int centuries, int halfCenturies ){
        if(noOfBatsmen < size-1){
            noOfBatsmen++;
            batsmans[noOfBatsmen] = new batsman(name, runsScored, centuries, halfCenturies);
            System.out.println("The new generated id is :" + batsman.getId());
            return batsman.getId();
        }else{
            return 0;
        }
    }

    //q.5 update batsman status
    public batsman updateBatsman(int id,int centuries,int halfCenturies){
        for(batsman b : batsmans){
            if (b != null && b.getId() == id) {
                b.setCenturies(centuries);
                b.setHalfCenturies(halfCenturies);
                System.out.println(b.getId() +" "+"updated halfCenturies status : "+ b.getHalfCenturies()+" "+ "updated Centuries Status : "+ b.getCenturies());
                return b;
            }
        }
        return null;
    }


    public static void main(String[] args) {
        Espncricinfo info = new Espncricinfo();
        int id = info.addBatsman("virat",5000,89,105);
        int id1 = info.addBatsman("rohit",8000,100,200);
        batsman[] batsmens = info.getBatsmans();
        for(batsman e : batsmens){
            if(e != null){
                System.out.println("Name :" + e.getName() +" "+ "runs : "+ e.getRunsScored()+" "+ "centuries : "+ e.getCenturies()+" "+"half-Centuries : " + e.getHalfCenturies());
            }
        }

        int e = info.getNoOfBatsmen();
        System.out.println("Total number of batsmens in the list : " + e);

        batsman batsman = info.updateBatsman(100002,300,105);
        System.out.println(batsman.getHalfCenturies());


    }
}
