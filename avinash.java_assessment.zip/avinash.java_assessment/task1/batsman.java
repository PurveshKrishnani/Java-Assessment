package task1;

class batsman{
    private String name;
    private int runsScored;
    private int centuries;
    private int halfCenturies;
    private static int id;

    private static int idGenerator =100000;

    // parameterized parameter
    public batsman(int id){
        this.id = ++idGenerator;
    }

    public batsman(String name, int runsScored, int centuries, int halfCenturies) {
        this.id = ++idGenerator;
        this.name = name;
        this.runsScored = runsScored;
        this.centuries = centuries;
        this.halfCenturies = halfCenturies;
    }
    // setters

    public static int getId() {
        return id;
    }
    public void setName(String name) {
        this.name = name;
    }

    public void setRunsScored(int runsScored) {
        this.runsScored = runsScored;
    }

    public void setCenturies(int centuries) {
        this.centuries = centuries;
    }

    public void setHalfCenturies(int halfCenturies) {
        this.halfCenturies = halfCenturies;
    }

    // getters
    public String getName() {
        return name;
    }

    public int getRunsScored() {
        return runsScored;
    }

    public int getCenturies() {
        return centuries;
    }

    public int getHalfCenturies() {
        return halfCenturies;
    }
}
