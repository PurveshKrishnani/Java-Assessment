package task2;

public class main {

    private int id;
    private static int idGenerator =100000;

    //default parameter
    public main(){ // constructor should be having same name as class
        this.id = ++idGenerator;
    }
    // parameterized parameter
    public main(int id){
        this.id = ++idGenerator;
    }

    // getter for id
    public int getId() {
        return id;
    }

    public static void main(String[] args) {
        main obj = new main();
        System.out.println("ID Without Parameter : "+obj.getId());
        main avi = new main();
        System.out.println("ID Without Parameter 2 : "+avi.getId());
        main para = new main(9);
        System.out.println("ID having parameter :" + para.getId());
    }

}
