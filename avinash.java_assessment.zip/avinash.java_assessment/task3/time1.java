package task3;

public class time1{

    public static void main(String[] args) {

        String time1 = "04:07:34";
        String[] time1Parts = time1.split(":");
        int h1 = Integer.parseInt(time1Parts[0]);
        int m1 = Integer.parseInt(time1Parts[1]);
        int s1 = Integer.parseInt(time1Parts[2]);

        String time2 = "04:07:34";
        String[] time2Parts = time2.split(":");
        int h2 = Integer.parseInt(time2Parts[0]);
        int m2 = Integer.parseInt(time2Parts[1]);
        int s2 = Integer.parseInt(time2Parts[2]);


        int s = s1-s2;
        if(s<0){
            s += 60;
            m1--;
        }
        int m = m1-m2;
        if(m<0){
            m += 60;
            h1--;
        }
        int h = h1-h2;
        if(h<0){
            h+=24;
        }
        System.out.println(h+":"+m+":"+s);
    }
}