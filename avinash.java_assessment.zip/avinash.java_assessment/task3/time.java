package task3;

public class time {
    public static int seconds(String time){
        String[] split = time.split(":");
        int hours = Integer.parseInt(split[0]);
        int min = Integer.parseInt(split[1]);
        int sec = Integer.parseInt(split[2]);

        return  hours*3600+min*60+sec;
    }
    public static String time(int tsec){
        int hours = tsec/3600;
        int min = hours/60;
        int sec = tsec%60;
        return String.format("%02d:%02d:%02d", hours, min, sec);
    }
    public static String subtractsec(String time1, String time2){
        int toseconds1 = seconds(time1);
        int toseconds2 = seconds(time2);

        int sub = toseconds1 - toseconds2;

        return time(sub);
    }

    public static void main(String[] args) {
        String time1 = "02:07:34";
        String time2 = "04:07:34";

        String diff = subtractsec(time1,time2);
        System.out.println(diff);

    }
}
